# 🐔 PoultryCaduceus

**A Bidirectional DNA Language Model for Chicken Genome**

PoultryCaduceus 是首个专门针对鸡（*Gallus gallus*）基因组预训练的 DNA 语言模型，基于 [Caduceus](https://github.com/kuleshov-group/caduceus) 架构。

## ✨ 特点

- 🧬 **鸡基因组专用**: 在 GRCg6a (~1.1 Gb) 基因组上预训练
- 🔄 **双向建模**: 基于 Mamba 的双向序列建模
- ⚡ **RC 等变性**: 内置反向互补等变性
- 📏 **长序列**: 支持 65,536 bp 上下文

## 📊 模型信息

| 参数 | 值 |
|------|-----|
| Base Model | caduceus-ph (4层) |
| Hidden Dim | 256 |
| Vocab Size | 16 |
| Sequence Length | 65,536 bp |
| Training Steps | 10,000 |
| Hardware | 4x H200 (80GB) |

## 🚀 快速开始

### 安装依赖

```bash
# 克隆仓库
git clone https://github.com/chengzhimin/poultry-caduceus.git
cd poultry-caduceus

# 设置环境
source setup_env.sh
```

### 加载模型

```python
from transformers import AutoModelForMaskedLM

# 从 HuggingFace 加载
model = AutoModelForMaskedLM.from_pretrained(
    "chengzhimin/poultry-caduceus",
    trust_remote_code=True
)

# 或从本地 checkpoint 加载
model = AutoModelForMaskedLM.from_pretrained(
    "./outputs/chicken_caduceus_10k/checkpoint-10000",
    trust_remote_code=True
)
```

### 获取序列嵌入

```python
import torch

# DNA 词汇表
DNA_VOCAB = {'A': 7, 'C': 8, 'G': 9, 'T': 10, 'N': 5, '[MASK]': 4}

# 编码序列
sequence = "ATGCGATCGATCGATCG"
input_ids = torch.tensor([[DNA_VOCAB.get(c, 5) for c in sequence]])

# 获取嵌入
model.eval()
with torch.no_grad():
    outputs = model(input_ids, output_hidden_states=True)
    embeddings = outputs.hidden_states[-1]  # (batch, seq_len, 256)
```

---

## 🔧 从头训练

### Step 1: 准备环境

```bash
# 创建 conda 环境
conda create -n caduceus_env python=3.10
conda activate caduceus_env

# 安装依赖
pip install torch transformers h5py biopython pyyaml tensorboard

# 安装 Caduceus (需要 CUDA)
pip install caduceus-dna
# 或从源码安装 mamba-ssm
```

### Step 2: 下载基础模型

从 [Caduceus 官方仓库](https://github.com/kuleshov-group/caduceus) 下载预训练模型：

```bash
# 下载 caduceus-ph 模型
git lfs install
git clone https://huggingface.co/kuleshov-group/caduceus-ph_seqlen-131k_d_model-256_n_layer-4 ./caduceus-ph-model
```

### Step 3: 准备数据

使用 Google Colab 运行数据准备 notebook（服务器无需联网）：

```bash
# 在 Colab 中运行
notebooks/data_preparation.ipynb

# 下载生成的数据文件
# chicken_pretrain_data_GRCg6a.tar.gz

# 上传到服务器并解压
tar -xzf chicken_pretrain_data_GRCg6a.tar.gz
```

数据目录结构：
```
chicken_caduceus_data/
├── train_65k.h5    # 训练集 (~58,000 序列)
└── val_65k.h5      # 验证集 (~1,200 序列)
```

### Step 4: 开始训练

```bash
# 单 GPU
python scripts/train_chicken_caduceus_v8.py --config configs/chicken_caduceus_10k.yaml

# 多 GPU (4x H200)
torchrun --nproc_per_node=4 scripts/train_chicken_caduceus_v8.py \
    --config configs/chicken_caduceus_10k.yaml
```

### Step 5: 训练输出

```
outputs/chicken_caduceus_10k/
├── checkpoint-1000/
├── checkpoint-2000/
├── ...
└── checkpoint-10000/    # 最终模型
    ├── config.json
    ├── pytorch_model.bin
    └── training_state.pt
```

---

## 📁 仓库结构

```
poultry-caduceus/
├── README.md
├── LICENSE
├── setup_env.sh                      # 环境设置
├── configs/
│   └── chicken_caduceus_10k.yaml     # 训练配置
├── scripts/
│   ├── chicken_dataset.py            # 数据集类
│   └── train_chicken_caduceus_v8.py  # 训练脚本
└── notebooks/
    └── data_preparation.ipynb        # 数据准备 (Colab)
```

---

## 📖 训练配置说明

```yaml
# chicken_caduceus_10k.yaml

model:
  pretrained_model: ./caduceus-ph-model  # 基础模型路径

data:
  train_path: chicken_caduceus_data/train_65k.h5
  val_path: chicken_caduceus_data/val_65k.h5
  seq_length: 65536      # 序列长度
  batch_size: 6          # 每 GPU batch size
  mlm_probability: 0.15  # 掩码比例
  rc_aug: true           # 反向互补增强

training:
  max_steps: 10000       # 训练步数
  warmup_steps: 500
  gradient_accumulation_steps: 2
  bf16: true             # 混合精度

optimizer:
  lr: 2e-4
  weight_decay: 0.01
```

---

## 🎯 应用场景

- **MPRA 预测**: 预测调控序列活性
- **eQTL 分析**: 识别表达数量性状位点
- **GWAS 精细定位**: 优先排序因果变异
- **调控元件注释**: 识别增强子、启动子等

---

## 📝 引用

如果使用本模型，请引用：

```bibtex
@article{poultrycaduceus2024,
  title={PoultryCaduceus: A Bidirectional DNA Language Model for Chicken Genome},
  author={Your Name},
  year={2024}
}
```

同时请引用 Caduceus 原文：

```bibtex
@article{schiff2024caduceus,
  title={Caduceus: Bi-Directional Equivariant Long-Range DNA Sequence Modeling},
  author={Schiff, Yair and Kao, Chia-Hsiang and Gokaslan, Aaron and Dao, Tri and Gu, Albert and Kuleshov, Volodymyr},
  journal={arXiv preprint arXiv:2403.03234},
  year={2024}
}
```

---

## 📜 License

MIT License

## 🔗 链接

- 🤗 **HuggingFace**: [chengzhimin/poultry-caduceus](https://huggingface.co/chengzhimin/poultry-caduceus)
- 🐔 **Caduceus**: [kuleshov-group/caduceus](https://github.com/kuleshov-group/caduceus)
