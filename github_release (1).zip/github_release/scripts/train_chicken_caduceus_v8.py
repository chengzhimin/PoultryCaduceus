#!/usr/bin/env python3
"""
Chicken Caduceus 训练脚本 (v8)
- 内置修复的ChickenGenomeDataset (支持'sequences'和'tokens' key)
- BF16混合精度训练
- 分布式训练支持
"""

import os
import sys
import argparse
import time
import random
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

import h5py
import numpy as np
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.distributed import DistributedSampler
from torch.cuda.amp import autocast, GradScaler

from transformers import (
    AutoModelForMaskedLM,
    AutoConfig,
    get_cosine_schedule_with_warmup,
)

import yaml

# 尝试导入tensorboard
try:
    from torch.utils.tensorboard import SummaryWriter
    HAS_TENSORBOARD = True
except ImportError:
    HAS_TENSORBOARD = False
    print("Warning: tensorboard not installed, logging disabled")


# =============================================================================
# DNA Vocabulary (与Caduceus官方一致, vocab_size=16)
# =============================================================================
DNA_VOCAB = {
    '[PAD]': 0, '[UNK]': 1, '[CLS]': 2, '[SEP]': 3, '[MASK]': 4,
    'N': 5, '.': 6, 'A': 7, 'C': 8, 'G': 9, 'T': 10,
    'R': 11, 'Y': 12, 'S': 13, 'W': 14, 'K': 15,
}

# 互补碱基映射
COMPLEMENT_MAP = {
    0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6,
    7: 10, 8: 9, 9: 8, 10: 7,  # A<->T, C<->G
    11: 11, 12: 12, 13: 13, 14: 14, 15: 15,
}


def reverse_complement(token_ids: np.ndarray) -> np.ndarray:
    """计算反向互补序列"""
    rc = token_ids[::-1].copy()
    for i in range(len(rc)):
        rc[i] = COMPLEMENT_MAP.get(int(rc[i]), rc[i])
    return rc


# =============================================================================
# Dataset (v5 修复版 - 内置)
# =============================================================================
class ChickenGenomeDataset(Dataset):
    """
    鸡基因组数据集 (HDF5格式)
    
    支持的HDF5格式:
    - 'sequences': (N, seq_len) uint8, 编码 A=7, C=8, G=9, T=10, N=11
    - 或 'tokens': 同上
    """
    
    def __init__(
        self,
        data_path: str,
        seq_length: int = 65536,
        mlm: bool = True,
        mlm_probability: float = 0.15,
        rc_aug: bool = True,
        max_samples: Optional[int] = None,
    ):
        self.data_path = Path(data_path)
        self.seq_length = seq_length
        self.mlm = mlm
        self.mlm_probability = mlm_probability
        self.rc_aug = rc_aug
        
        self.h5_file = h5py.File(self.data_path, 'r')
        
        # ===== 关键修复: 自动检测数据key =====
        if 'sequences' in self.h5_file:
            self.data_key = 'sequences'
        elif 'tokens' in self.h5_file:
            self.data_key = 'tokens'
        else:
            available_keys = list(self.h5_file.keys())
            raise KeyError(f"HDF5文件中找不到 'sequences' 或 'tokens'。可用keys: {available_keys}")
        
        self.tokens = self.h5_file[self.data_key]
        
        self.n_samples = len(self.tokens)
        if max_samples is not None:
            self.n_samples = min(self.n_samples, max_samples)
        
        # 检测数据编码范围
        sample_data = self.tokens[0][:100]
        unique_vals = np.unique(sample_data)
        
        print(f"加载数据集: {self.data_path}")
        print(f"  数据key: '{self.data_key}'")
        print(f"  样本数: {self.n_samples}")
        print(f"  原始序列长度: {self.tokens.shape[1]}")
        print(f"  目标序列长度: {self.seq_length}")
        print(f"  编码范围: {unique_vals.min()}-{unique_vals.max()}")
    
    def __len__(self):
        return self.n_samples
    
    def __getitem__(self, idx):
        tokens = np.array(self.tokens[idx], dtype=np.int64)
        
        # 截断或填充
        if len(tokens) > self.seq_length:
            tokens = tokens[:self.seq_length]
        elif len(tokens) < self.seq_length:
            padding = np.zeros(self.seq_length - len(tokens), dtype=np.int64)
            tokens = np.concatenate([tokens, padding])
        
        tokens = np.clip(tokens, 0, 15)
        
        # RC增强
        if self.rc_aug and random.random() < 0.5:
            tokens = reverse_complement(tokens)
        
        # MLM
        if self.mlm:
            input_ids, labels = self._apply_mlm(tokens)
        else:
            input_ids = tokens.copy()
            labels = tokens.copy()
        
        return {
            'input_ids': torch.tensor(input_ids, dtype=torch.long),
            'labels': torch.tensor(labels, dtype=torch.long),
        }
    
    def _apply_mlm(self, tokens: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        input_ids = tokens.copy()
        labels = np.zeros_like(tokens)  # 0 = ignore
        
        # 只mask有效碱基 (A=7, C=8, G=9, T=10)
        valid_mask = (tokens >= 7) & (tokens <= 10)
        valid_indices = np.where(valid_mask)[0]
        
        if len(valid_indices) == 0:
            return input_ids, labels
        
        n_mask = max(1, int(len(valid_indices) * self.mlm_probability))
        mask_indices = np.random.choice(valid_indices, size=n_mask, replace=False)
        
        for idx in mask_indices:
            labels[idx] = tokens[idx]
            rand = random.random()
            if rand < 0.8:
                input_ids[idx] = 4  # [MASK]
            elif rand < 0.9:
                input_ids[idx] = random.choice([7, 8, 9, 10])
        
        return input_ids, labels
    
    def close(self):
        self.h5_file.close()


# =============================================================================
# Trainer
# =============================================================================
def setup_distributed():
    if 'RANK' in os.environ:
        rank = int(os.environ['RANK'])
        local_rank = int(os.environ['LOCAL_RANK'])
        world_size = int(os.environ['WORLD_SIZE'])
        dist.init_process_group(backend='nccl')
        torch.cuda.set_device(local_rank)
        return rank, local_rank, world_size
    return 0, 0, 1


def cleanup_distributed():
    if dist.is_initialized():
        dist.destroy_process_group()


def is_main_process(rank):
    return rank == 0


def print_rank0(msg, rank=0):
    if is_main_process(rank):
        print(msg)


def load_config(config_path: str) -> Dict[str, Any]:
    with open(config_path) as f:
        return yaml.safe_load(f)


def save_checkpoint(model, optimizer, scheduler, step, loss, config, output_dir, rank):
    if not is_main_process(rank):
        return
    
    checkpoint_dir = output_dir / f"checkpoint-{step}"
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    model_to_save = model.module if hasattr(model, 'module') else model
    model_to_save.save_pretrained(checkpoint_dir)
    
    torch.save({
        'step': step,
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict() if scheduler else None,
        'loss': loss,
        'config': config,
    }, checkpoint_dir / 'training_state.pt')
    
    print(f"✓ Checkpoint saved: {checkpoint_dir}")


class Trainer:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.rank, self.local_rank, self.world_size = setup_distributed()
        self.device = torch.device(f'cuda:{self.local_rank}')
        
        print_rank0("\n" + "="*60, self.rank)
        print_rank0("Chicken Caduceus Trainer v8", self.rank)
        print_rank0("="*60, self.rank)
        print_rank0(f"Rank: {self.rank}/{self.world_size} | Device: {self.device}", self.rank)
        
        self.output_dir = Path(config['training']['output_dir'])
        if is_main_process(self.rank):
            self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.use_amp = config['training'].get('bf16', True)
        print_rank0(f"混合精度: {'BF16' if self.use_amp else 'FP32'}", self.rank)
        
        self._init_model()
        self._init_data()
        self._init_optimizer()
        
        self.log_interval = int(config['training'].get('log_interval', 10))
        self.save_interval = int(config['training'].get('save_interval', 1000))
        self.eval_interval = int(config['training'].get('eval_interval', 500))
    
    def _init_model(self):
        model_config = self.config['model']
        pretrained_model = model_config.get('pretrained_model')
        
        print_rank0(f"\n加载模型: {pretrained_model}", self.rank)
        
        config = AutoConfig.from_pretrained(
            pretrained_model,
            trust_remote_code=True,
            local_files_only=True
        )
        if config.pad_token_id is None:
            config.pad_token_id = 0
        
        self.model = AutoModelForMaskedLM.from_pretrained(
            pretrained_model,
            config=config,
            trust_remote_code=True,
            local_files_only=True,
            torch_dtype=torch.float32,
        )
        
        if self.model.config.pad_token_id is None:
            self.model.config.pad_token_id = 0
        
        self.model = self.model.to(self.device)
        
        if self.world_size > 1:
            self.model = DDP(
                self.model,
                device_ids=[self.local_rank],
                output_device=self.local_rank,
                find_unused_parameters=False,
            )
        
        total_params = sum(p.numel() for p in self.model.parameters())
        print_rank0(f"参数量: {total_params:,}", self.rank)
    
    def _init_data(self):
        data_config = self.config['data']
        seq_length = int(data_config.get('seq_length', 65536))
        
        train_ds = ChickenGenomeDataset(
            data_path=data_config['train_path'],
            seq_length=seq_length,
            mlm=True,
            mlm_probability=float(data_config.get('mlm_probability', 0.15)),
            rc_aug=data_config.get('rc_aug', True),
        )
        
        val_ds = ChickenGenomeDataset(
            data_path=data_config['val_path'],
            seq_length=seq_length,
            mlm=True,
            mlm_probability=float(data_config.get('mlm_probability', 0.15)),
            rc_aug=False,
        )
        
        train_sampler = DistributedSampler(
            train_ds, num_replicas=self.world_size, rank=self.rank, shuffle=True
        ) if self.world_size > 1 else None
        
        val_sampler = DistributedSampler(
            val_ds, num_replicas=self.world_size, rank=self.rank, shuffle=False
        ) if self.world_size > 1 else None
        
        batch_size = int(data_config.get('batch_size', 1))
        
        self.train_loader = DataLoader(
            train_ds, batch_size=batch_size, sampler=train_sampler,
            shuffle=(train_sampler is None),
            num_workers=int(data_config.get('num_workers', 4)),
            pin_memory=True, drop_last=True,
        )
        
        self.val_loader = DataLoader(
            val_ds, batch_size=batch_size, sampler=val_sampler,
            shuffle=False,
            num_workers=int(data_config.get('num_workers', 4)),
            pin_memory=True,
        )
        
        self.train_sampler = train_sampler
        print_rank0(f"训练: {len(train_ds)} 样本 | 验证: {len(val_ds)} 样本", self.rank)
    
    def _init_optimizer(self):
        opt_config = self.config['optimizer']
        lr = float(opt_config.get('lr', 2e-4))
        weight_decay = float(opt_config.get('weight_decay', 0.01))
        
        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=lr,
            betas=(0.9, 0.999),
            weight_decay=weight_decay,
        )
        
        max_steps = int(self.config['training'].get('max_steps', 100000))
        warmup_steps = int(self.config['training'].get('warmup_steps', 1000))
        
        self.scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup_steps,
            num_training_steps=max_steps,
        )
        
        print_rank0(f"优化器: AdamW (lr={lr}, warmup={warmup_steps})", self.rank)
    
    @torch.no_grad()
    def evaluate(self):
        self.model.eval()
        total_loss = 0.0
        n_batches = 0
        
        for batch in self.val_loader:
            input_ids = batch['input_ids'].to(self.device)
            labels = batch['labels'].to(self.device)
            
            with autocast(dtype=torch.bfloat16 if self.use_amp else torch.float32):
                outputs = self.model(input_ids=input_ids, labels=labels)
            
            total_loss += outputs.loss.item()
            n_batches += 1
            
            if n_batches >= 50:  # 限制eval batch数
                break
        
        self.model.train()
        return total_loss / max(n_batches, 1)
    
    def train(self):
        training_config = self.config['training']
        max_steps = int(training_config.get('max_steps', 100000))
        grad_accum = int(training_config.get('gradient_accumulation_steps', 1))
        max_grad_norm = float(training_config.get('max_grad_norm', 1.0))
        
        print_rank0(f"\n开始训练...", self.rank)
        print_rank0(f"  最大步数: {max_steps}", self.rank)
        print_rank0(f"  梯度累积: {grad_accum}", self.rank)
        print_rank0(f"  有效batch: {int(self.config['data']['batch_size']) * self.world_size * grad_accum}", self.rank)
        
        self.model.train()
        global_step = 0
        epoch = 0
        log_loss = 0.0
        best_val_loss = float('inf')
        
        scaler = GradScaler(enabled=self.use_amp)
        start_time = time.time()
        
        while global_step < max_steps:
            epoch += 1
            if self.train_sampler:
                self.train_sampler.set_epoch(epoch)
            
            for batch_idx, batch in enumerate(self.train_loader):
                input_ids = batch['input_ids'].to(self.device)
                labels = batch['labels'].to(self.device)
                
                with autocast(dtype=torch.bfloat16 if self.use_amp else torch.float32):
                    outputs = self.model(input_ids=input_ids, labels=labels)
                    loss = outputs.loss / grad_accum
                
                scaler.scale(loss).backward()
                log_loss += loss.item()
                
                if (batch_idx + 1) % grad_accum == 0:
                    scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_grad_norm)
                    scaler.step(self.optimizer)
                    scaler.update()
                    self.scheduler.step()
                    self.optimizer.zero_grad()
                    
                    global_step += 1
                    
                    # Logging
                    if global_step % self.log_interval == 0 and is_main_process(self.rank):
                        avg_loss = log_loss / self.log_interval * grad_accum
                        lr = self.scheduler.get_last_lr()[0]
                        elapsed = time.time() - start_time
                        steps_per_sec = global_step / elapsed
                        eta = (max_steps - global_step) / steps_per_sec / 3600
                        
                        print(f"Step {global_step}/{max_steps} | "
                              f"Loss: {avg_loss:.4f} | LR: {lr:.2e} | "
                              f"Speed: {steps_per_sec:.2f} steps/s | ETA: {eta:.1f}h")
                        log_loss = 0.0
                    
                    # Evaluation
                    if global_step % self.eval_interval == 0:
                        val_loss = self.evaluate()
                        if is_main_process(self.rank):
                            print(f"  → Val Loss: {val_loss:.4f}")
                            if val_loss < best_val_loss:
                                best_val_loss = val_loss
                                save_checkpoint(
                                    self.model, self.optimizer, self.scheduler,
                                    global_step, val_loss, self.config,
                                    self.output_dir, self.rank
                                )
                    
                    # Regular checkpoint
                    if global_step % self.save_interval == 0:
                        save_checkpoint(
                            self.model, self.optimizer, self.scheduler,
                            global_step, log_loss, self.config,
                            self.output_dir, self.rank
                        )
                    
                    if global_step >= max_steps:
                        break
        
        # Final save
        save_checkpoint(
            self.model, self.optimizer, self.scheduler,
            global_step, log_loss, self.config,
            self.output_dir, self.rank
        )
        
        print_rank0(f"\n训练完成! 总步数: {global_step}", self.rank)
        cleanup_distributed()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    args = parser.parse_args()
    
    config = load_config(args.config)
    trainer = Trainer(config)
    trainer.train()


if __name__ == '__main__':
    main()
